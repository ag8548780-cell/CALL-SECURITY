package com.callsecurity.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Sync {
    fun configured() = Config.URL.isNotBlank() && Config.KEY.isNotBlank()
    private fun req(url: String, method: String = "GET", body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("apikey", Config.KEY)
        if (Config.KEY.startsWith("eyJ")) c.setRequestProperty("Authorization", "Bearer " + Config.KEY)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val s = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, s)
    }
    fun run(c: Context): String {
        if (!configured()) return "सर्वर अभी सेट नहीं है (GitHub Secrets देखें)"
        return try {
            val p = Prefs(c); val db = Db(c)
            var since = p.since; var total = 0; var off = 0
            while (true) {
                var u = Config.URL + "/rest/v1/spam_database?select=number,level,category,updated_at&order=updated_at.asc&limit=1000&offset=$off"
                if (p.since.isNotEmpty()) u += "&updated_at=gt." + URLEncoder.encode(p.since, "UTF-8")
                val (code, body) = req(u)
                if (code != 200) return "सर्वर त्रुटि ($code)"
                val a = JSONArray(body)
                if (a.length() == 0) break
                db.upsertSpam(a); total += a.length(); off += a.length()
                since = a.getJSONObject(a.length() - 1).getString("updated_at")
                if (a.length() < 1000) break
            }
            p.since = since
            "सिंक पूरा: $total नए/अपडेट नंबर"
        } catch (e: Exception) { "इंटरनेट/सर्वर उपलब्ध नहीं" }
    }
    fun online(n: String): String {
        if (!configured()) return "सर्वर सेट नहीं है"
        return try {
            val (code, body) = req(Config.URL + "/rest/v1/number_reputation?select=level,reporter_count&number=eq." + URLEncoder.encode(n, "UTF-8"))
            if (code != 200) return "सर्वर त्रुटि ($code)"
            val a = JSONArray(body)
            if (a.length() == 0) "कोई रिपोर्ट नहीं (अनजान)" else a.getJSONObject(0).let { it.getString("level") + " · रिपोर्टर: " + it.getInt("reporter_count") }
        } catch (e: Exception) { "इंटरनेट/सर्वर उपलब्ध नहीं" }
    }
    fun report(c: Context, n: String, cat: String): String {
        if (!configured()) return "सर्वर अभी सेट नहीं है"
        return try {
            val j = JSONObject().put("number", n).put("category", cat).put("device_id", Prefs(c).device)
            val (code, body) = req(Config.URL + "/functions/v1/report", "POST", j.toString())
            if (code != 200) return "रिपोर्ट विफल ($code)"
            when (JSONObject(body).optString("result")) {
                "ok" -> "रिपोर्ट दर्ज हुई। धन्यवाद!"
                "duplicate" -> "आप यह रिपोर्ट पहले कर चुके हैं।"
                "rate_limited" -> "आज की रिपोर्ट सीमा पूरी हो गई।"
                "safe_number" -> "यह सत्यापित सुरक्षित नंबर है।"
                else -> "अज्ञात उत्तर"
            }
        } catch (e: Exception) { "इंटरनेट/सर्वर उपलब्ध नहीं" }
    }
}
