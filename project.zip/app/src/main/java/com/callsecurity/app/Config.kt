package com.callsecurity.app
object Config { const val URL = ""; const val KEY = "" }
