package com.callsecurity.app
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.telecom.Call
import android.telecom.CallScreeningService

class ScreeningService : CallScreeningService() {
    override fun onScreenCall(d: Call.Details) {
        var block = false; var act = "allowed"; var name: String? = null; var n = ""; var lvl: String? = null
        var p: Prefs? = null
        try {
            p = Prefs(this)
            val raw = d.handle?.schemeSpecificPart ?: ""
            n = Util.norm(raw)
            if (d.callDirection == Call.Details.DIRECTION_INCOMING) {
                val db = Db(this)
                name = Util.contactName(this, raw)
                if (p.auto) {
                    if (db.inBlock(n)) { block = true; act = "blocked_personal" }
                    else if (name == null && !db.isSafe(n)) {
                        lvl = db.level(n)
                        if (lvl == "dangerous" || (lvl == "spam" && p.blockSpam)) { block = true; act = "blocked_spam" }
                    }
                } else if (name == null && !db.isSafe(n)) lvl = db.level(n)
            } else { act = "outgoing" }
        } catch (e: Exception) { block = false }
        val r = CallResponse.Builder()
        if (block) r.setDisallowCall(true).setRejectCall(true).setSkipNotification(true)
        respondToCall(d, r.build())
        try {
            if (act == "outgoing") return
            Db(this).log(n, act)
            val pr = p ?: return
            if (block) { notifyBlocked(n); return }
            if (!pr.voice) return
            val hi = pr.lang == "hi"
            val text = when {
                name != null -> if (hi) "ध्यान दीजिए! $name का फोन आ रहा है। कृपया कॉल उठाने की कोशिश करें।" else "Attention! Call from $name."
                lvl == "spam" || lvl == "suspicious" -> if (hi) "सावधान! इस नंबर को स्पैम या संदिग्ध रिपोर्ट किया गया है।" else "Warning! This number is reported as spam or suspicious."
                pr.unknownAlert -> if (hi) "अनजान नंबर से कॉल आ रही है।" else "Call from an unknown number."
                else -> null
            }
            if (text != null) Speaker.speak(this, text, pr.lang, pr.gender)
        } catch (e: Exception) {}
    }
    private fun notifyBlocked(n: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("blocked", "Blocked calls", NotificationManager.IMPORTANCE_DEFAULT))
        val nt = Notification.Builder(this, "blocked").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("CALL SECURITY: कॉल ब्लॉक की गई").setContentText(n).build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), nt)
    }
}
