package com.callsecurity.app
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val go = Runnable { showMain() }
    private var inWelcome = true
    private val NAVY = Color.parseColor("#061A45")
    private val GREY = Color.parseColor("#9FB0D3")
    private val cats = listOf(
        "spam_call" to "स्पैम कॉल", "fraud_call" to "फ्रॉड कॉल", "fake_bank_call" to "फर्जी बैंक कॉल",
        "lottery_fraud" to "लॉटरी धोखाधड़ी", "fake_customer_care" to "फर्जी ग्राहक सेवा",
        "suspicious_sms" to "संदिग्ध SMS", "phishing_link" to "फिशिंग लिंक")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "sync", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<SyncWorker>(12, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
        showWelcome()
        h.postDelayed(go, 10000)
    }
    override fun onDestroy() { h.removeCallbacks(go); super.onDestroy() }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sz: Float = 16f, bold: Boolean = false, c: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, dp(4), 0, dp(4))
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun sw(t: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        text = t; isChecked = on; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, v -> f(v) }
    }
    private fun field(hint: String, phone: Boolean) = EditText(this).apply {
        this.hint = hint; setTextColor(Color.WHITE); setHintTextColor(GREY)
        if (phone) inputType = InputType.TYPE_CLASS_PHONE
    }
    private fun screen(center: Boolean, build: LinearLayout.() -> Unit) {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(24))
            if (center) gravity = Gravity.CENTER
            build()
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(NAVY); isFillViewport = true; addView(l) })
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun photoView(s: Int): View {
        val f = File(filesDir, "owner.jpg")
        val lp = LinearLayout.LayoutParams(dp(s), dp(s)).apply { setMargins(0, dp(12), 0, dp(12)); gravity = Gravity.CENTER_HORIZONTAL }
        if (f.exists()) {
            return ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(f.path)); layoutParams = lp; scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
                }
            }
        }
        return tv("मालिक की फोटो\nयहाँ दिखेगी", 13f, false, GREY).apply {
            gravity = Gravity.CENTER; layoutParams = lp
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(2), GREY, dp(6).toFloat(), dp(4).toFloat()) }
        }
    }
    private fun pick() {
        h.removeCallbacks(go)
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1)
    }
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 1 && res == RESULT_OK && d?.data != null) {
            try {
                val b = contentResolver.openInputStream(d.data!!)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }!!
                val m = minOf(b.width, b.height)
                val sq = Bitmap.createBitmap(b, (b.width - m) / 2, (b.height - m) / 2, m, m)
                File(filesDir, "owner.jpg").outputStream().use { Bitmap.createScaledBitmap(sq, 300, 300, true).compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (e: Exception) { toast("फोटो नहीं खुल सकी") }
        }
        if (inWelcome) { showWelcome(); h.postDelayed(go, 10000) } else showMain()
    }

    private fun showWelcome() {
        inWelcome = true
        screen(true) {
            addView(tv("🛡️", 56f)); addView(tv("CALL SECURITY", 26f, true))
            addView(photoView(130))
            addView(tv("Anmol Gupta", 22f, true))
            addView(tv("Founder & Owner: Anmol Gupta"))
            addView(tv("Creator: Anmol Gupta"))
            addView(tv("Created & Owned By Anmol Gupta", 15f, true, GREY))
            addView(tv("आपकी सुरक्षा, हमारी प्राथमिकता। स्वागत है!"))
            addView(btn("मालिक की फोटो अपलोड करें") { pick() })
            addView(btn("आगे बढ़ें (Skip)") { h.removeCallbacks(go); showMain() })
        }
    }

    private fun showMain() {
        h.removeCallbacks(go); inWelcome = false
        val p = Prefs(this); val db = Db(this)
        val rm = getSystemService(RoleManager::class.java)
        val held = rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        screen(false) {
            addView(tv("🛡️ CALL SECURITY", 24f, true))
            addView(tv("Created & Owned By Anmol Gupta", 13f, false, GREY))
            addView(tv(if (held) "✅ कॉल स्क्रीनिंग चालू है" else "⚠️ कॉल स्क्रीनिंग चालू नहीं है", 16f, true))
            if (!held) addView(btn("CALL SECURITY को Call Screening ऐप बनाएँ") {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2)
            })
            addView(btn("कॉन्टैक्ट और नोटिफिकेशन अनुमति दें") {
                requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS, android.Manifest.permission.POST_NOTIFICATIONS), 3)
            })
            addView(tv("सुरक्षा आँकड़े (इस फोन के वास्तविक रिकॉर्ड)", 16f, true))
            addView(tv("जाँची गई कॉल: ${db.count("select count(*) from log where action<>'outgoing'")}\n" +
                "ब्लॉक की गई (स्पैम): ${db.count("select count(*) from log where action='blocked_spam'")}\n" +
                "ब्लॉक की गई (आपकी सूची): ${db.count("select count(*) from log where action='blocked_personal'")}\n" +
                "ब्लॉक लिस्ट: ${db.count("select count(*) from blocklist")}   सुरक्षित नंबर: ${db.count("select count(*) from safe")}\n" +
                "ऑफलाइन स्पैम डेटाबेस: ${db.count("select count(*) from spam")} नंबर", 15f, false, GREY))
            addView(tv("सेटिंग", 16f, true))
            addView(sw("ऑटो ब्लॉक (खतरनाक + आपकी ब्लॉक लिस्ट)", p.auto) { p.auto = it })
            addView(sw("‘स्पैम’ स्तर वाले नंबर भी ब्लॉक करें", p.blockSpam) { p.blockSpam = it })
            addView(sw("Voice Caller ID (आवाज़ में नाम बोलना)", p.voice) { p.voice = it })
            addView(sw("अनजान कॉल की घोषणा", p.unknownAlert) { p.unknownAlert = it })
            addView(btn("आवाज़ भाषा: " + (if (p.lang == "hi") "हिंदी" else "English")) { p.lang = if (p.lang == "hi") "en" else "hi"; showMain() })
            addView(btn("आवाज़: " + (if (p.gender == "female") "महिला" else "पुरुष")) { p.gender = if (p.gender == "female") "male" else "female"; showMain() })
            addView(btn("आवाज़ टेस्ट करें") {
                Speaker.speak(this@MainActivity, if (p.lang == "hi") "ध्यान दीजिए! राहुल का फोन आ रहा है। कृपया कॉल उठाने की कोशिश करें।" else "Attention! Call from Rahul.", p.lang, p.gender)
            })
            addView(tv("नंबर जाँच और रिपोर्ट", 16f, true))
            val et = field("+91XXXXXXXXXX", true); addView(et)
            val res = tv("", 15f); 
            val sp = Spinner(this@MainActivity).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, cats.map { it.second }) }
            fun valid(): String? {
                val n = Util.norm(et.text.toString())
                if (!Regex("^\\+[1-9][0-9]{7,14}$").matches(n)) { res.text = "अमान्य नंबर"; return null }
                return n
            }
            addView(btn("जाँचें") {
                val n = valid()
                if (n != null) {
                    val name = Util.contactName(this@MainActivity, n)
                    val s = when {
                        db.inBlock(n) -> "आपकी ब्लॉक लिस्ट में"
                        db.isSafe(n) -> "सुरक्षित"
                        name != null -> "सुरक्षित (कॉन्टैक्ट: $name)"
                        else -> when (db.level(n)) { "dangerous" -> "खतरनाक"; "spam" -> "स्पैम"; "suspicious" -> "संदिग्ध"; else -> "अनजान" }
                    }
                    res.text = "$n\nऑफलाइन: $s\nऑनलाइन जाँच हो रही है…"
                    Thread { val o = Sync.online(n); runOnUiThread { res.text = "$n\nऑफलाइन: $s\nऑनलाइन: $o" } }.start()
                }
            })
            addView(sp)
            addView(btn("रिपोर्ट भेजें") {
                val n = valid()
                if (n != null) Thread { val m = Sync.report(this@MainActivity, n, cats[sp.selectedItemPosition].first); runOnUiThread { toast(m) } }.start()
            })
            addView(res)
            addView(tv("व्यक्तिगत ब्लॉक लिस्ट (फोन से बाहर नहीं जाती)", 16f, true))
            val bn = field("+91XXXXXXXXXX", true); addView(bn)
            addView(btn("ब्लॉक में जोड़ें") { val n = Util.norm(bn.text.toString()); if (n.length >= 8) { db.addBlock(n); showMain() } })
            db.blocks().forEach { n -> addView(btn("✕ $n") { db.delBlock(n); showMain() }) }
            addView(tv("सुरक्षित कॉन्टैक्ट सूची", 16f, true))
            val sn = field("नाम", false); val spn = field("+91XXXXXXXXXX", true); addView(sn); addView(spn)
            addView(btn("सुरक्षित में जोड़ें") { val n = Util.norm(spn.text.toString()); if (n.length >= 8 && sn.text.isNotBlank()) { db.addSafe(n, sn.text.toString()); showMain() } })
            db.safes().forEach { (n, nm) -> addView(btn("✕ $nm · $n") { db.delSafe(n); showMain() }) }
            addView(tv("ऑनलाइन डेटाबेस", 16f, true))
            addView(btn("अभी स्पैम डेटाबेस अपडेट करें") {
                toast("सिंक हो रहा है…")
                Thread { val m = Sync.run(this@MainActivity); runOnUiThread { toast(m); showMain() } }.start()
            })
            addView(tv("सुरक्षा हिस्ट्री", 16f, true))
            val lg = db.logs()
            addView(tv(if (lg.isEmpty()) "अभी कुछ नहीं" else lg.joinToString("\n"), 13f, false, GREY))
            addView(tv("मालिक की जानकारी", 16f, true))
            addView(photoView(110))
            addView(btn("मालिक की फोटो बदलें") { pick() })
            addView(tv("Anmol Gupta\nFounder & Owner · Creator: Anmol Gupta\nCALL SECURITY – Created & Owned By Anmol Gupta", 14f))
            addView(tv("प्राइवेसी: कॉन्टैक्ट, ब्लॉक लिस्ट और कॉल हिस्ट्री इसी फोन में रहते हैं। कॉल रिकॉर्ड नहीं होती। केवल आपकी भेजी रिपोर्ट (नंबर, श्रेणी, गुप्त डिवाइस-कोड) सर्वर पर जाती है।", 13f, false, GREY))
            addView(btn("मेरा सारा लोकल डेटा हटाएँ") {
                db.clearAll(); p.clear(); File(filesDir, "owner.jpg").delete(); toast("डेटा हटा दिया गया"); showMain()
            })
        }
    }
}
