package com.callsecurity.app
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
class SyncWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { Sync.run(applicationContext); return Result.success() }
}
