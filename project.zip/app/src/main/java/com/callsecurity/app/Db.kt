package com.callsecurity.app
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray

class Db(c: Context) : SQLiteOpenHelper(c, "cs.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("create table spam(number text primary key, level text, category text)")
        d.execSQL("create table blocklist(number text primary key)")
        d.execSQL("create table safe(number text primary key, name text)")
        d.execSQL("create table log(id integer primary key autoincrement, ts integer, number text, action text)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
    private fun exists(t: String, n: String): Boolean =
        readableDatabase.rawQuery("select 1 from $t where number=?", arrayOf(n)).use { it.moveToFirst() }
    fun level(n: String): String? =
        readableDatabase.rawQuery("select level from spam where number=?", arrayOf(n)).use { if (it.moveToFirst()) it.getString(0) else null }
    fun inBlock(n: String) = exists("blocklist", n)
    fun isSafe(n: String) = exists("safe", n)
    fun addBlock(n: String) { writableDatabase.execSQL("insert or ignore into blocklist values(?)", arrayOf<Any>(n)) }
    fun delBlock(n: String) { writableDatabase.execSQL("delete from blocklist where number=?", arrayOf<Any>(n)) }
    fun addSafe(n: String, name: String) { writableDatabase.execSQL("insert or replace into safe values(?,?)", arrayOf<Any>(n, name)) }
    fun delSafe(n: String) { writableDatabase.execSQL("delete from safe where number=?", arrayOf<Any>(n)) }
    fun blocks(): List<String> = readableDatabase.rawQuery("select number from blocklist", null).use { c -> val l = ArrayList<String>(); while (c.moveToNext()) l.add(c.getString(0)); l }
    fun safes(): List<Pair<String, String>> = readableDatabase.rawQuery("select number,name from safe", null).use { c -> val l = ArrayList<Pair<String, String>>(); while (c.moveToNext()) l.add(Pair(c.getString(0), c.getString(1))); l }
    fun log(n: String, a: String) { writableDatabase.execSQL("insert into log(ts,number,action) values(?,?,?)", arrayOf<Any>(System.currentTimeMillis(), n, a)) }
    fun count(sql: String): Int = readableDatabase.rawQuery(sql, null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun logs(): List<String> = readableDatabase.rawQuery("select ts,number,action from log order by id desc limit 20", null).use { c ->
        val l = ArrayList<String>()
        while (c.moveToNext()) l.add(java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(java.util.Date(c.getLong(0))) + "  " + c.getString(1) + "  " + c.getString(2))
        l
    }
    fun upsertSpam(a: JSONArray) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val cat = if (o.isNull("category")) "" else o.getString("category")
                d.execSQL("insert or replace into spam values(?,?,?)", arrayOf<Any>(o.getString("number"), o.getString("level"), cat))
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun clearAll() {
        val d = writableDatabase
        d.execSQL("delete from spam"); d.execSQL("delete from blocklist"); d.execSQL("delete from safe"); d.execSQL("delete from log")
    }
}
