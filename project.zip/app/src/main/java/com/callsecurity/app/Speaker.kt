package com.callsecurity.app
import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var queued: (() -> Unit)? = null

    fun speak(c: Context, text: String, lang: String, gender: String) {
        val job = {
            val t = tts
            if (t != null) {
                val loc = if (lang == "en") Locale("en", "IN") else Locale("hi", "IN")
                t.setLanguage(loc)
                val v = t.voices?.firstOrNull {
                    val n = it.name.lowercase()
                    it.locale.language == loc.language &&
                        (if (gender == "male") n.contains("male") && !n.contains("female") else n.contains("female"))
                }
                if (v != null) t.voice = v
                t.setPitch(if (gender == "male") 0.8f else 1.1f)
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cs")
            }
        }
        if (ready) { job(); return }
        queued = job
        if (tts == null) {
            tts = TextToSpeech(c.applicationContext) { s ->
                if (s == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    queued?.invoke(); queued = null
                }
            }
        }
    }
}
