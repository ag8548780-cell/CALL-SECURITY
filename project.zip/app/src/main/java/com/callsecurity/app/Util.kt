package com.callsecurity.app
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

object Util {
    fun norm(r: String): String {
        var d = r.filter { it.isDigit() || it == '+' }
        if (d.startsWith("00")) d = "+" + d.drop(2)
        if (!d.startsWith("+")) {
            if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
            if (d.length == 10) d = "+91$d" else if (d.length == 12 && d.startsWith("91")) d = "+$d"
        }
        return d
    }
    fun contactName(c: Context, raw: String): String? {
        if (raw.isEmpty()) return null
        if (c.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(raw))
        c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }
}
