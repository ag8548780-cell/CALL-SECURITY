package com.callsecurity.app
import android.content.Context
class Prefs(c: Context) {
    private val s = c.getSharedPreferences("cs", 0)
    var auto: Boolean
        get() = s.getBoolean("auto", true)
        set(v) { s.edit().putBoolean("auto", v).apply() }
    var blockSpam: Boolean
        get() = s.getBoolean("blockSpam", false)
        set(v) { s.edit().putBoolean("blockSpam", v).apply() }
    var voice: Boolean
        get() = s.getBoolean("voice", false)
        set(v) { s.edit().putBoolean("voice", v).apply() }
    var unknownAlert: Boolean
        get() = s.getBoolean("unk", true)
        set(v) { s.edit().putBoolean("unk", v).apply() }
    var lang: String
        get() = s.getString("lang", "hi") ?: "hi"
        set(v) { s.edit().putString("lang", v).apply() }
    var gender: String
        get() = s.getString("gender", "female") ?: "female"
        set(v) { s.edit().putString("gender", v).apply() }
    var since: String
        get() = s.getString("since", "") ?: ""
        set(v) { s.edit().putString("since", v).apply() }
    val device: String
        get() {
            var d = s.getString("dev", null)
            if (d == null) {
                d = java.util.UUID.randomUUID().toString().replace("-", "")
                s.edit().putString("dev", d).apply()
            }
            return d
        }
    fun clear() { s.edit().clear().apply() }
}
